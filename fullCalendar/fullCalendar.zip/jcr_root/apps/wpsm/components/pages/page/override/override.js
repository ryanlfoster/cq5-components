CQ.Ext.override(CQ.wcm.Sidekick, {
        previewReload: true,
});