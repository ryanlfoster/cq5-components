var oldContainerWidth = 0; // width of container class from CSS used to determine when layout size changes

$(function() 
{

	oldContainerWidth = $(".container").width();

    //prevent tab links from clicking, will work when JS is disabled
    $('#wpsm-mainNav .wpsm-mainNavLink a').click(function(event) {
        event.preventDefault();
    });

    $('[data-toggle=collapse]').each(function() {
		this.addEventListener('click', function() {}, false);
	});
	
	$("#wpsm-mainNav").on('click', ".wpsm-mainNavLink", function() {

		var target = $(this).data("target");
		if(target)
		{
			if($(this).hasClass("wpsm-activeNav"))
			{
				$(target).hide();
				$(".wpsm-superMenuMostInnerArea", target).hide();
				$(this).removeClass("wpsm-activeNav");
				$(".wpsm-mainNavSubHeading li", "#wpsm-mainNav").removeClass("wpsm-activeSubNav");
				if($(window).width() > 767)
				{
					$("#wpsm-superMenu .container").css({'height':'0px'});
				}
			}
			else
			{


                if($(window).width() > 767) {
                    $(".wpsm-mainNavLink", "#wpsm-mainNav").removeClass("wpsm-activeNav");
					$(".wpsm-mainNavMainPane").hide();
                }
                $(this).addClass("wpsm-activeNav");
				$(".wpsm-mainNavSubHeading", target).show();
                $(".wpsm-superMenuMostInnerArea.wpsm-4col", target).show();
				$(target).show();
				if($(window).width() > 767)
				{
					$(target).find("li").eq(0).click();
				}
			}
		}
	});

	
	$("#wpsm-mainNav").on('click', ".wpsm-mainNavSubHeading li", function() {
		var target = $(this).data("target");
		if(target)
		{
			if($(window).width() > 767)
			{
				if(!$(this).hasClass("wpsm-activeSubNav"))
				{
					$(".wpsm-mainNavSubHeading li", "#wpsm-mainNav").removeClass("wpsm-activeSubNav");
					$(this).addClass("wpsm-activeSubNav");
					$(".wpsm-superMenuMostInnerArea").hide();
					
					$(target).show();
					setNavHeight();
				}
			}
			else
			{
				if($(this).hasClass("wpsm-activeSubNav"))
				{
					$(target).hide();
					$(".wpsm-superMenuMostInnerArea", target).hide();
					$(this).removeClass("wpsm-activeSubNav");
				}
				else
				{
					//$(".wpsm-mainNavSubHeading li", "#wpsm-mainNav").removeClass("wpsm-activeSubNav");
					$(this).addClass("wpsm-activeSubNav");
					//$(".wpsm-superMenuMostInnerArea").hide();
					$(target).show();
				}
				
			}
		}
	});

})



$(window).resize(function() 
{	
	// listen for change to media layout
	var newContainerWidth = parseInt($(".container").width());
	if(newContainerWidth != oldContainerWidth)
	{
		if(oldContainerWidth < 736 && newContainerWidth >= 736 )
		{
			// transition from mobile to desktop...
			// close any active navigation, which also fixes some potential height issues
			$(".wpsm-activeNav").click(); 
		}
		setNavHeight(); // change navigation container size
		oldContainerWidth = newContainerWidth;
	}
});



// set height of nav container to match new contents
function setNavHeight()
{
	if($(window).width() > 767)
	{
		$(".wpsm-activeSubNav").show();
		var subNavHeight = $(".wpsm-activeSubNav").parents(".wpsm-mainNavSubHeading").height();
		var linksHeight = $(".wpsm-activeSubNav").children(".wpsm-superMenuMostInnerArea").height();
		
		// console.log("H: " + subNavHeight + " - " + linksHeight);
		if(!subNavHeight && !linksHeight) return;
			
		var navHeight = 160; // default to be overwritten
		if(subNavHeight > linksHeight) 
		{
			// if subnav is longer, extend links height so subnav tab isn't hanging in space
			$(".wpsm-activeSubNav").children(".wpsm-superMenuMostInnerArea").css({'min-height':(subNavHeight+'px')});
			navHeight = subNavHeight + 30;
		}
		else
		{
			navHeight = linksHeight + 50;
		}
		
		$("#wpsm-superMenu .container").css({'height':(navHeight+'px')});
		$("#wpsm-superMenu").css({'height':'auto'});
		
	}
	else
	{
		$("#wpsm-superMenu .container").css({'height':'auto'});
		$(".wpsm-superMenuMostInnerArea").css({'min-height':'1px'});
		
	}
}