

var wpsm_wantTo_oldContainerWidth = 0;

$(function() 
{
	wpsm_wantTo_oldContainerWidth = $(".container").width();

	wpsm_initAllWantToAreas();
	
	$(".wpsm-wantTo").on('click', "li", function() {
		var el = $(this);

        //remove active when in tablet or desktop view, keep open for mobile
        if($(window).width() > 767) {
			el.siblings().removeClass("wpsm-activeSubNav");
        }

		if(wpsm_wantTo_oldContainerWidth < 755 && el.hasClass("wpsm-activeSubNav"))
		{
			el.removeClass("wpsm-activeSubNav");
		}
		else
		{
			el.addClass("wpsm-activeSubNav");
			wpsm_setWantToHeight(el.closest('ul'));
		}
		
	});
});




// setup each I Want To section for appropriate screen size
function wpsm_initAllWantToAreas()
{
    //prevent tabheadings being clickable links:
    $(".wpsm-wantToSubHeading .tabheading a").click(function(event){
  		event.preventDefault();
	});

    var containerWidth = parseInt($(".container").width());
	if(containerWidth >= 755)
	{
		// desktop/tablet...
		
		// set first element as active
		$(".wpsm-wantTo ul").each(function() {
			$('li', $(this)).removeClass("wpsm-activeSubNav");
			$('li', $(this)).first().addClass("wpsm-activeSubNav");
		});
		
		$(".wpsm-wantToSubHeading").show();
		$(".wpsm-wantToSubHeading").css('height','auto');
		wpsm_setHeightOfAllWantToAreas();
	}
	else
	{
		// mobile...
		// hide all inner selections
		$(".wpsm-wantToSubHeading").hide();
		$(".wpsm-wantTo ul").each(function() {
			$(this).css('height','auto');
			$('li', $(this)).removeClass("wpsm-activeSubNav");
		});
		
	}
	
	
}


// set initial height of each I Want To section to cover visible links
function wpsm_setHeightOfAllWantToAreas()
{
	$(".wpsm-wantTo ul").each(function() {
		wpsm_setWantToHeight($(this));
	});
}



// set height of I Want To section to cover visible links.
// some elements are absolutely positioned, so the natural height is no good if there are many links.
// var el should be the ul element within the .wpsm-wantTo div
function wpsm_setWantToHeight(el)
{
	if(parseInt($(".container").width()) >= 755)
	{
		// find max column height
		var maxItemHeight = 0;
		$(".wpsm-activeSubNav .wpsm-wantToMainPane-Col", el).each(function() {
			maxItemHeight = Math.max(maxItemHeight, $(this).outerHeight(true));
		});
		maxItemHeight += 20; // account for padding
		
		// find left side category link height
		var totalLinkHeight = 0;
		$("li", el).each(function() {
			totalLinkHeight += $(this).outerHeight(true);
		});
	
		var setHeightTo = Math.max(maxItemHeight, totalLinkHeight);
		el.height(setHeightTo);
	}	
	
}


$(window).resize(function() 
{	
	// listen for change to media layout
	var newContainerWidth = parseInt($(".container").width());
	if(newContainerWidth != wpsm_wantTo_oldContainerWidth)
	{
		if(wpsm_wantTo_oldContainerWidth < 755 && newContainerWidth >= 755)
		{
			// transition from mobile to desktop/tablet...
			wpsm_initAllWantToAreas();
		}
		else if(wpsm_wantTo_oldContainerWidth >= 755 && newContainerWidth < 755)
		{
			// transition from desktop/tablet to mobile...
			wpsm_initAllWantToAreas();
		}
		else if(newContainerWidth >= 755)
		{
			// transition from desktop/tablet to desktop/tablet...
			wpsm_setHeightOfAllWantToAreas()
		}
		
		wpsm_wantTo_oldContainerWidth = newContainerWidth;
	}

});


