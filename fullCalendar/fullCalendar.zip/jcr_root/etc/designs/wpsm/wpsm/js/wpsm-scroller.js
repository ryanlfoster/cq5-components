// scroll the horizontal scroll elements on click


/*	wpsm_initScrolling
 * initialize scrolling 
 * Parameters:
 * el: parent scrollable element (in which can be found all of our necessary subclasses)
 * rows: int - number of rows of items within the scroller
 */
function wpsm_initScrolling(el, rows)
{
	if (arguments.length == 1) rows = 1;
	
	// set up inner div width
	var itemsCount = 0;
	var lastItemWidth = 0;
	var itemsWidthWithMargin = 0;
	$(".wpsm-sideScrollerScroller .wpsm-sideScrollerItem", el).each(function() {
		itemsCount++;
		lastItemWidth = $(this).outerWidth(true);
		itemsWidthWithMargin += lastItemWidth;
	});
	
	var containerWidth = lastItemWidth * Math.ceil((itemsWidthWithMargin / rows) / lastItemWidth);
	$(".wpsm-sideScrollerScroller", el).width(containerWidth);
	
	// set up left and right arrow buttons to scroll
	$(el).on('click', ".wpsm-sideScrollerLeftLink", function() {
		wpsm_scroll(el, true);
	});
	$(el).on('click', ".wpsm-sideScrollerRightLink", function() {
		wpsm_scroll(el, false);
	});
}

/*	wpsm_scroll
 * perform scrolling
 * Parameters:
 * el: parent scrollable element (in which can be found all of our necessary subclasses)
 * left: boolean - true to scroll left, false to scroll right
 */
function wpsm_scroll(el, left)
{
	var innerWidth = $(".wpsm-sideScrollerScroller", el).width();
	var outerWidth = $(".wpsm-sideScrollerScrollable", el).width();
	var currentPosition = $(".wpsm-sideScrollerScrollable", el).scrollLeft();
	var moveTo = 0;
	
	if(left)
	{
		moveTo = Math.max(0, (currentPosition - outerWidth));
	}
	else
	{
		var maxLeft = innerWidth - outerWidth;
		moveTo = Math.min(maxLeft, (currentPosition + outerWidth));
	}
	$(".wpsm-sideScrollerScrollable", el).animate({scrollLeft: moveTo}, 700);
}


function wpsm_hideScrollButtons(){
		var scroller = document.getElementById("wpsm-formScroller"); 
		var items = scroller.getElementsByTagName("a"); 
        if (items.length <= 4) {
            $(".wpsm-sideScrollerRightLink").hide();
            $(".wpsm-sideScrollerLeftLink").hide();
    	}
    }

