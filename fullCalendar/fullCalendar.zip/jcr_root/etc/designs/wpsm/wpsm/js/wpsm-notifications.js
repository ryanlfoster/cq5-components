
$(document).ready(function() {
	
	// init visibility
	$(".wpsm-notification:first-of-type").show();
	
	// alert bell toggle
	$(document).on('click', "#wpsm-alertArea", function() {
		if($("#wpsm-alerts").is(":visible"))
		{
			var intervalHandle = $(".container", "#wpsm-alerts").data('wpsm_intervalHandle');
			if(intervalHandle) clearInterval(intervalHandle);
		}

		$("#wpsm-alerts").slideToggle();
	});
	
	// alert close 'X'
	$("#wpsm-alerts").on('click', ".wpsm-closeAlerts", function() {
		$("#wpsm-alerts").slideUp();
	});
	
	// left arrow
	$(document).on('click', ".wpsm-notificationArrowLeft", function() {
		wpsm_notificationGoLeft($(this).parent(), false);
	});

	// right arrow
	$(document).on('click', ".wpsm-notificationArrowRight", function() {
		wpsm_notificationGoRight($(this).parent(), false);
	});
	
	// auto rotate
	$(".wpsm-notificationArea").each(function() {
		var targetEl = $(this).parent();
		var thisInterval = setInterval(function() { wpsm_notificationGoRight(targetEl, true); }, 30000);
		targetEl.data('wpsm_intervalHandle', thisInterval);
	});
	
	// listen for clicks in iOS
	$('.wpsm-notificationArrowRight').each(function() {
		this.addEventListener('click', function() {}, false);
	});
	$('.wpsm-notificationArrowLeft').each(function() {
		this.addEventListener('click', function() {}, false);
	});
	$('.wpsm-closeAlerts').each(function() {
		this.addEventListener('click', function() {}, false);
	});
	

	
});

function wpsm_notificationGoLeft(el)
{
	var intervalHandle = el.data('wpsm_intervalHandle');
	if(intervalHandle)
	{
		clearInterval(intervalHandle);
	}
	
	var visEl = $(".wpsm-notification", el).filter(":visible");
	var nextEl = visEl.prev(".wpsm-notification");
	visEl.hide();
	if(nextEl.length) {
		nextEl.show();
	} else {
		$(".wpsm-notification", el).last().show();
	}
}

function wpsm_notificationGoRight(el, fromInterval)
{
	if(!fromInterval)
	{
		var intervalHandle = el.data('wpsm_intervalHandle');
		if(intervalHandle)
		{
			clearInterval(intervalHandle);
		}
	}
	
	var visEl = $(".wpsm-notification", el).filter(":visible");
	var nextEl = visEl.next(".wpsm-notification");
	visEl.hide();
	if(nextEl.length) {
		nextEl.show();
	} else {
		$(".wpsm-notification", el).first().show();
	}
}

