
$(function() 
{
	// hover
	$(".wpsm-commissionerOverlayLinkDiv").hover(
		function() {
			$('.wpsm-commissionerOverlay').hide();
			if(parseInt($(".container").width()) >= 755)
			{
				$(".wpsm-commissionerOverlay", $(this)).show();
			}
		}, 
		function () {
			$(".wpsm-commissionerOverlay", $(this)).hide();
		}
	);

	
	// close button
	$("#wpsm-commissionerOverlaySection").on('click', ".wpsm-commOverClose", function() {
		$(this).closest('.wpsm-commissionerOverlay').hide();
	});
	
});
