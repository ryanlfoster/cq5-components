CQ.Ext.namespace("WPSM", "WPSM.wcm");

WPSM.wcm.SendEmailAction = {
    "text": "Send Email",
    "context": [ CQ.wcm.Sidekick.PAGE ],
    "handler": function() {

        var linebreak = "%0D%0A";
        var sidekick = this;
        var currentPath = sidekick.getPath();
        var homePath = CQ.Util.getAbsoluteParent(sidekick.getPath(), 2);
        var previewUrl = "http://" + window.location.host;; 
        var currentPage = CQ.utils.WCM.getPage(currentPath);

		var fullTitle = "";
        var currentPageURL = CQ.HTTP.externalize(currentPath + "/jcr:content.json");
        var currentPageResponse = CQ.HTTP.get(currentPageURL);
        if (CQ.HTTP.isOk(currentPageResponse)) {
        	var data = CQ.Util.eval(currentPageResponse);
        	fullTitle = data["jcr:title"];
        }


		var addresses = "";//between the speech mark goes the receptient. Seperate addresses with a ;
        var body = "";//write the message text between the speech marks or put a variable in the place of the speech marks
        body = linebreak + " Draft of this content is ready for your review: " + linebreak +
        previewUrl + sidekick.getPath() +".html";

        var subject = "Web page for review : "+ escape(fullTitle); //between the speech marks goes the subject of the message

        if ((body + subject).length > 244) {
            var offset = (body + subject).length - 244;
            if (offset > subject.length) {
                subject = "...";
            }
            else {
                subject = subject.substring(0, subject.length - (offset + 3)) + "...";
            }
        }

        var href = "mailto:" + addresses + "?"
                 + "subject=" + subject + "&"
                 + "body=" + body +linebreak;
        var wndMail;

        wndMail = window.open(href, "_blank", "scrollbars=yes,resizable=yes,width=10,height=10");
        if(wndMail)
        {
            wndMail.close();    
        }

    } 
}; 

// add this action to the default list
CQ.wcm.Sidekick.DEFAULT_ACTIONS.push(WPSM.wcm.SendEmailAction);