
// http://arshaw.com/fullcalendar/

$(document).ready(function() {
	//Get jsonFeed URL
	var jsonFeed=window.location.pathname+window.location.search;
    jsonFeed=jsonFeed.substring(0,jsonFeed.indexOf(".html"))+".wpsm-mini-events.html";
    
	$('#wpsm-miniCalendarDiv').fullCalendar({
		events: {url : jsonFeed},	// change to appropriate CQ URL
		editable: false,
		aspectRatio: 1.2,
		header: {
		    left:   'prev',
		    center: 'title',
		    right:  'next',
		},
		loading: function(isLoading, view)
		{
			if(isLoading) $("#wpsm-miniCalendarEventList").text('No events this month'); // clear old events from list
		},
		eventRender: function(event, element, view) 
		{
			var startMoment = moment(event.start);
			var endMoment = event.end ? moment(event.end) : false;
			var sDate = startMoment.format("YYYY-MM-DD")
			
			// mark start date table cell as an event date
			$('td[data-date="' + sDate + '"]', '#wpsm-miniCalendarDiv').addClass('wpsm-eventDate');
			
			// mark the rest of the days of multi-day event
			if(endMoment && !endMoment.isSame(startMoment, 'day'))
			{
				var thisMoment = moment(sDate);
				thisMoment.add('days', 1);
				while(thisMoment.isBefore(endMoment))
				{
					sDate = thisMoment.format("YYYY-MM-DD")
					// console.log("thisMoment: " + sDate);
					$('td[data-date="' + sDate + '"]', '#wpsm-miniCalendarDiv').addClass('wpsm-eventDate');
					thisMoment.add('days', 1);
				}
			}
			
			// don't do the default render
			return false;
		},
		eventDataTransform: function(event) 
		{
			// add event to the event list below calendar
			
			if($("#wpsm-miniCalendarEventList").text() == 'No events this month') $("#wpsm-miniCalendarEventList").text(''); // clear
			
			var startMoment = moment(event.start);
			var endMoment = event.end ? moment(event.end) : false;
			
			var s = '<div class="wpsm-miniCalendarEvent"><div class="wpsm-miniCalendarEventDateCol"><div class="wpsm-miniCalendarEventDateBlock">';
			s += '<div class="wpsm-miniCalendarEventDateBlockMonth">' + startMoment.format("MMM") + '</div>';
			
			if(endMoment && !endMoment.isSame(startMoment, 'day'))
			{
				var endString = event.allDay ? endMoment.subtract('days',1).format("DD") : endMoment.format("DD");
				s += '<div class="wpsm-miniCalendarEventDateBlockDays">' + startMoment.format("DD") + '-' + endMoment.format("DD") + '</div>';
			} 
			else 
			{
				s += '<div class="wpsm-miniCalendarEventDateBlockDay">' + startMoment.format("DD") + '</div>';
			}
			
			s += '</div></div>';
			
			// date line - trying to account for varying dates, times and ranges
			s += '<div class="wpsm-miniCalendarEventDescription"><div class="wpsm-miniCalendarEventDescriptionDate">';
			if(endMoment)
			{
				var oneDay = endMoment.isSame(startMoment, 'day');
				if(!oneDay) 
				{
					s += startMoment.format("MMMM DD, YYYY") + ' - ' + endMoment.format("MMMM DD, YYYY");
				}
				else if(oneDay && !event.allDay)
				{
					s += startMoment.format("MMMM DD, YYYY, h:mm a") + ' - ' + endMoment.format("h:mm a");
				}
				else if(!event.allDay)
				{
					s += startMoment.format("MMMM DD, YYYY, h:mm a") + ' - ' + endMoment.format("MMMM DD, YYYY, h:mm a");
				}
			}
			else if(!event.allDay)
			{
				s += startMoment.format("MMMM DD, YYYY, h:mm a");
			}
			else
			{
				s += startMoment.format("MMMM DD, YYYY");
			}
			s += '</div>';
			
			s += '<div class="wpsm-miniCalendarEventDescriptionTitle">';
			if(event.url) s += '<a href="' + event.url + '">';
			s += event.title;
			if(event.url) s += '</a>';
			s += '</div>';
			
			s += '<div class="wpsm-miniCalendarEventDescriptionText">' + event.description + '</div>';
			s += '</div>';
			s += '</div>';
			
			$("#wpsm-miniCalendarEventList").append(s);
			
			return event;
			
		}
	});
	
	
	
	
	
});

/*
<div class="wpsm-miniCalendarEvent">
	<div class="wpsm-miniCalendarEventDateCol">
		<div class="wpsm-miniCalendarEventDateBlock">
			<div class="wpsm-miniCalendarEventDateBlockMonth">Jun</div>
			<div class="wpsm-miniCalendarEventDateBlockDay">22</div>
		</div>
	</div>
	<div class="wpsm-miniCalendarEventDescription">
		<div class="wpsm-miniCalendarEventDescriptionDate">June 22, 2014</div>
		<div class="wpsm-miniCalendarEventDescriptionTitle">Important Meeting</div>
		<div class="wpsm-miniCalendarEventDescriptionText">
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
		</div>
	</div>
</div>

<div class="wpsm-miniCalendarEvent">
	<div class="wpsm-miniCalendarEventDateCol">
		<div class="wpsm-miniCalendarEventDateBlock">
			<div class="wpsm-miniCalendarEventDateBlockMonth">Jun</div>
			<div class="wpsm-miniCalendarEventDateBlockDays">12-16</div><!-- different class for smaller text -->
		</div>
	</div>
	<div class="wpsm-miniCalendarEventDescription">
		<div class="wpsm-miniCalendarEventDescriptionDate">June 12-16, 2014</div>
		<div class="wpsm-miniCalendarEventDescriptionTitle">Week Long Conference</div>
		<div class="wpsm-miniCalendarEventDescriptionText">
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
			doloremque
		</div>
	</div>
</div>

*/